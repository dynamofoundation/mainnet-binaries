<html>

<head>
<title>Pending Payout</title>
<meta http-equiv="refresh" content="5">
<!--//css -->

<style>

table

{

border-style:solid;
border-width:1px;
}

</style>

</head>

<body>

 <?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('c:\pool\mining_pool.db'); 
      }
   }
   
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Database connect success";
      //echo "\n";
   }
   $sql =<<<EOF
      SELECT share_wallet, count(share_hash) as numofshare, count(*) *100.0/sum(count(*)) over () as percent_pool from share where share_status='pending' group by 1 order by 3 desc;

//select count(*) from share where share_status = 'pending'; 
//select share_wallet, count(*) from share where share_status = 'pending' group by 1;
//select share_wallet, count(*) as sharePending, count(*) *100.0/sum(count(*)) over () as percent_pool from share where share_status='pending' group by 1;
//select share_wallet, share_hash, count(*) as sharePending, count(*) *100.0/sum(count(*)) over () as percent_pool from share where share_status='pending' group by 1,2;

//select share_wallet, count(share_hash) as numofshare, count(*) *100.0/sum(count(*)) over () as percent_pool from share where share_status='pending' group by 1;

EOF;

   $ret = $db->query($sql);
echo "Pending Payout - Auto refresh every 5 seconds";
echo "<br>";
echo "<br>";
echo "<table border='1'>


<tr>
	<th>wallet</th>
	<th>number of shares</th>
	<th>percentage of pool</th>
</tr>";

   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) 
   {
	echo "<tr>";
	echo "<td>" . $row['share_wallet'] . "</td>";
	echo "<td>" . $row['numofshare'] . "</td>";
	echo "<td>" . $row['percent_pool'] . "</td>";
	echo "</tr>";
   }
	echo "</table>";

    echo "Operation done successfully\n";
    $db->close();

?>

</body>

</html>