<html>

<head>

<!--//css -->

<style>

table

{

border-style:solid;
border-width:1px;
}

</style>

</head>

<body>

 <?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('c:\pool\mining_pool.db'); 
      }
   }
   
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Database connect success";
      //echo "\n";
   }
   $sql =<<<EOF
      SELECT reward_timestamp,reward_height,'xxx_block_hash_xxx', reward_amount  from reward;
EOF;

   $ret = $db->query($sql);
echo "Blocks Mined";
echo "<br>";
echo "<table border='1'>


<tr>
	<th>timestamp</th>
	<th>block height</th>
	<th>block hash</th>
	<th>block reward</th>
</tr>";

   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) 
   {
	echo "<tr>";
	echo "<td>" . $row['reward_timestamp'] . "</td>";
	echo "<td>" . $row['reward_height'] . "</td>";
	echo "<td>" . $row['xxx_block_hash_xxx'] . "</td>";
	echo "<td>" . $row['reward_amount'] . "</td>";
	echo "</tr>";
   }
	echo "</table>";

    echo "Operation done successfully\n";
    $db->close();

?>

</body>

</html>