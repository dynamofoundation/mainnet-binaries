<html>

<head>

<!--//css -->

<style>

table

{

border-style:solid;
border-width:1px;
}

</style>

</head>

<body>

 <?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('c:\pool\mining_pool.db'); 
      }
   }
   
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Database connect success";
      //echo "\n";
   }
   $sql =<<<EOF
      SELECT payout_timestamp,payout_wallet,payout_amount  from payout;;
EOF;

   $ret = $db->query($sql);
echo "Payout History";
echo "<br>";
echo "<table border='1'>


<tr>
	<th>timestamp</th>
	<th>wallet address</th>
	<th>payout amount sent</th>
</tr>";

   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) 
   {
	echo "<tr>";
	echo "<td>" . $row['payout_timestamp'] . "</td>";
	echo "<td>" . $row['payout_wallet'] . "</td>";
	echo "<td>" . $row['payout_amount'] . "</td>";
	echo "</tr>";
   }
	echo "</table>";

    echo "Operation done successfully\n";
    $db->close();

?>

</body>

</html>